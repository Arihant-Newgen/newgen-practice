package overriding;
class JK extends Bank 
{
	int getRateOfInterest(){return 6;}  

}
