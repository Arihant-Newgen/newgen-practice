package overriding;

public class Axis extends Bank {
	int getRateOfInterest(){return 9;}  
}
