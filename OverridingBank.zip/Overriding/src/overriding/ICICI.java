package overriding;

public class ICICI extends Bank {
	int getRateOfInterest(){return 7;}  
}
