package overriding;

public class BankTest {
     public static void main(String args[])
     {
    	 SBI s=new SBI();
    	 JK jk=new JK();
    	 ICICI i= new ICICI();
    	 Axis a= new Axis();
    	 System.out.println("The rate of interest is-:" + s.getRateOfInterest());
    	 System.out.println("The rate of interest is-:" + jk.getRateOfInterest());
    	 System.out.println("The rate of interest is-:" + i.getRateOfInterest());
    	 System.out.println("The rate of interest is-:" + a.getRateOfInterest());
    	 
    	 
     }
}
